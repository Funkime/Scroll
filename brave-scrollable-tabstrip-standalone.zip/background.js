'use strict';
// Standalone tab-switcher: mouse wheel over the tab-bar area switches the
// active tab in the SAME window/monitor the wheel event happened in.
// No external mod (Windhawk or otherwise) required.

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== 'TAB_STRIP_SCROLL') return;
  const windowId = sender.tab?.windowId;
  if (windowId == null) { sendResponse({ ok: false }); return; }
  handleScroll(msg.direction, windowId).then(sendResponse);
  return true; // keep the message channel open for the async response
});

async function handleScroll(direction, windowId) {
  // Query tabs scoped to the exact window the wheel event fired in,
  // rather than "the current/focused window" (which can be wrong when
  // multiple Chrome windows/monitors are open).
  const tabs = await chrome.tabs.query({ windowId });
  if (!tabs?.length) return { ok: false };

  // Respect Chrome's actual tab order (index), not array order.
  tabs.sort((a, b) => a.index - b.index);

  const cur = tabs.findIndex(t => t.active);
  if (cur === -1) return { ok: false };

  const next = direction === 'right'
    ? (cur + 1) % tabs.length
    : (cur - 1 + tabs.length) % tabs.length;

  if (next === cur) return { ok: true, title: tabs[cur].title }; // only one tab

  try {
    const updated = await chrome.tabs.update(tabs[next].id, { active: true });
    return { ok: true, title: updated?.title || tabs[next].title };
  } catch (e) {
    return { ok: false, error: String(e) };
  }
}
