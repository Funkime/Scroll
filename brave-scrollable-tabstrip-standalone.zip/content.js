'use strict';
// Standalone tab switcher — no Windhawk / external mod required.
// A content script can never receive wheel events over the browser's real
// tab strip (that's native chrome UI, outside the page's reach), so instead
// we watch for wheel scrolling near the very top edge of the page content
// and use that as a stand-in gesture to switch tabs.

const TAB_BAR_H = 40;   // px from top of viewport that counts as the "zone"
const DEBOUNCE  = 150;  // ms between switches
const MIN_DELTA = 12;   // ignore tiny/accidental wheel ticks
let last = 0;

window.addEventListener('wheel', e => {
  if (e.clientY > TAB_BAR_H) return;
  if (Math.abs(e.deltaY) < MIN_DELTA) return;
  // Don't hijack zoom (Ctrl+wheel) or other modified gestures.
  if (e.ctrlKey || e.metaKey || e.altKey || e.shiftKey) return;

  const now = Date.now();
  if (now - last < DEBOUNCE) return;
  last = now;

  e.preventDefault();
  e.stopPropagation();

  const direction = e.deltaY > 0 ? 'right' : 'left';
  chrome.runtime.sendMessage({ type: 'TAB_STRIP_SCROLL', direction }, res => {
    if (chrome.runtime.lastError) return; // page/tab torn down mid-flight
    if (res?.ok && res.title) showToast(res.title, direction);
  });
}, { passive: false, capture: true });

// --- lightweight, self-destructing feedback toast (not a persistent strip) ---
let toastEl = null;
let toastTimer = null;

function showToast(title, direction) {
  if (!toastEl) {
    toastEl = document.createElement('div');
    toastEl.setAttribute('style', [
      'position:fixed', 'top:8px',
      direction === 'right' ? 'right:8px' : 'left:8px',
      'z-index:2147483647', 'background:rgba(20,24,36,0.92)', 'color:#e6e6e6',
      'font:12px -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif',
      'padding:6px 10px', 'border-radius:6px', 'pointer-events:none',
      'box-shadow:0 2px 8px rgba(0,0,0,.35)', 'opacity:0',
      'transition:opacity .15s ease', 'max-width:240px',
      'white-space:nowrap', 'overflow:hidden', 'text-overflow:ellipsis'
    ].join(';'));
    document.documentElement.appendChild(toastEl);
  }
  toastEl.style.left = direction === 'left' ? '8px' : '';
  toastEl.style.right = direction === 'right' ? '8px' : '';
  toastEl.textContent = title || 'Tab switched';
  requestAnimationFrame(() => { toastEl.style.opacity = '1'; });
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { if (toastEl) toastEl.style.opacity = '0'; }, 700);
}
