'use strict';
// Fallback content script — only acts when Windhawk mod is NOT installed.
// Detects wheel in top 50px and asks background to switch active tab.
const TAB_BAR_H = 50;
const DEBOUNCE  = 120;
let last = 0;

window.addEventListener('wheel', e => {
  if (e.clientY > TAB_BAR_H) return;
  if (Math.abs(e.deltaY) < 15)   return;
  const now = Date.now();
  if (now - last < DEBOUNCE)     return;
  last = now;
  e.preventDefault();
  e.stopPropagation();
  chrome.runtime.sendMessage({
    type: 'TAB_STRIP_SCROLL',
    direction: e.deltaY > 0 ? 'right' : 'left'
  });
}, { passive: false, capture: true });
