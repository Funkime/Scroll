'use strict';
// Receives scroll commands from content.js and switches tabs accordingly
// (fallback when Windhawk is not installed — switches active tab instead)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== 'TAB_STRIP_SCROLL') return;
  handleScroll(msg.direction, sender.tab?.windowId).then(sendResponse);
  return true;
});

async function handleScroll(direction, windowId) {
  const win = await chrome.windows.getCurrent({ populate: true });
  const tabs = win.tabs;
  if (!tabs?.length) return;
  const cur = tabs.findIndex(t => t.active);
  if (cur === -1) return;
  const next = direction === 'right'
    ? (cur + 1) % tabs.length
    : (cur - 1 + tabs.length) % tabs.length;
  await chrome.tabs.update(tabs[next].id, { active: true });
  return { ok: true };
}
