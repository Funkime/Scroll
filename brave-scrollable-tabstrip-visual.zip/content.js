'use strict';
// Visual scrollable tab strip — a custom overlay recreated inside the page,
// since extensions cannot draw into or scroll Chrome's real native tab bar.
//
// Behaviour:
//  - A thin hotspot at the very top of the viewport reveals the strip on hover.
//  - The strip lists every tab in this window (favicon + title), horizontally
//    scrollable with the mouse wheel.
//  - Click a tab to switch to it, click the × to close it.

const HOTSPOT_H  = 6;   // px — invisible hover trigger at the top edge
const BAR_H      = 36;  // px — visible strip height
const HIDE_DELAY = 500; // ms grace period before auto-hiding

let tabsData = [];
let hideTimer = null;

const hotspot = document.createElement('div');
const bar = document.createElement('div');

function showBar() {
  clearTimeout(hideTimer);
  bar.style.top = '0';
}

function scheduleHide() {
  clearTimeout(hideTimer);
  hideTimer = setTimeout(() => { bar.style.top = '-' + BAR_H + 'px'; }, HIDE_DELAY);
}

function buildUI() {
  Object.assign(hotspot.style, {
    position: 'fixed', top: '0', left: '0', right: '0',
    height: HOTSPOT_H + 'px', zIndex: '2147483645', background: 'transparent'
  });

  Object.assign(bar.style, {
    position: 'fixed', top: '-' + BAR_H + 'px', left: '0', right: '0',
    height: BAR_H + 'px', zIndex: '2147483646',
    background: 'rgba(16,19,28,0.97)', boxShadow: '0 2px 10px rgba(0,0,0,.4)',
    display: 'flex', alignItems: 'center', gap: '4px',
    overflowX: 'auto', overflowY: 'hidden', padding: '0 6px',
    transition: 'top .15s ease',
    fontFamily: '-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif',
    scrollbarWidth: 'thin'
  });

  document.documentElement.appendChild(hotspot);
  document.documentElement.appendChild(bar);

  // Hovering either the hotspot or the bar keeps it open; leaving both hides it.
  hotspot.addEventListener('mouseenter', showBar);
  bar.addEventListener('mouseenter', showBar);
  hotspot.addEventListener('mouseleave', scheduleHide);
  bar.addEventListener('mouseleave', scheduleHide);

  // Turn vertical wheel motion into horizontal scroll of the strip.
  bar.addEventListener('wheel', e => {
    e.preventDefault();
    bar.scrollLeft += (Math.abs(e.deltaY) > Math.abs(e.deltaX) ? e.deltaY : e.deltaX);
  }, { passive: false });
}

function render() {
  bar.innerHTML = '';
  tabsData.forEach(t => {
    const pill = document.createElement('div');
    Object.assign(pill.style, {
      display: 'flex', alignItems: 'center', gap: '6px',
      height: '27px', padding: '0 8px', borderRadius: '6px',
      flexShrink: '0', cursor: 'pointer', maxWidth: '180px',
      background: t.active ? '#2a3553' : '#1b2030',
      border: '1px solid ' + (t.active ? '#3b4a73' : 'transparent'),
      color: t.active ? '#9cc0ff' : '#c7c7c7', fontSize: '11px'
    });

    if (t.favIconUrl) {
      const icon = document.createElement('img');
      icon.src = t.favIconUrl;
      icon.referrerPolicy = 'no-referrer';
      icon.style.cssText = 'width:14px;height:14px;flex-shrink:0;border-radius:2px';
      icon.onerror = () => icon.remove();
      pill.appendChild(icon);
    }

    const label = document.createElement('span');
    label.textContent = t.title || 'Tab';
    label.style.cssText = 'overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:130px';
    pill.appendChild(label);

    const close = document.createElement('span');
    close.textContent = '×';
    close.title = 'Закрыть вкладку';
    close.style.cssText = 'margin-left:2px;opacity:.45;padding:0 3px;border-radius:3px;font-size:13px;line-height:1';
    close.addEventListener('mouseenter', () => close.style.opacity = '1');
    close.addEventListener('mouseleave', () => close.style.opacity = '.45');
    close.addEventListener('click', ev => {
      ev.stopPropagation();
      chrome.runtime.sendMessage({ type: 'STS_CLOSE_TAB', tabId: t.id });
    });
    pill.appendChild(close);

    pill.addEventListener('click', () => {
      chrome.runtime.sendMessage({ type: 'STS_ACTIVATE_TAB', tabId: t.id });
    });

    bar.appendChild(pill);
    if (t.active) {
      requestAnimationFrame(() => pill.scrollIntoView({ inline: 'center', block: 'nearest' }));
    }
  });
}

chrome.runtime.onMessage.addListener(msg => {
  if (msg.type === 'STS_TABS_UPDATE') {
    tabsData = msg.tabs || [];
    render();
  }
});

function init() {
  buildUI();
  chrome.runtime.sendMessage({ type: 'STS_GET_TABS' }, res => {
    if (chrome.runtime.lastError) return;
    tabsData = res?.tabs || [];
    render();
  });
}

if (document.readyState !== 'loading') init();
else document.addEventListener('DOMContentLoaded', init, { once: true });
