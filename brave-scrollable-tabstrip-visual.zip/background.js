'use strict';
// Backend for the visual tab-strip overlay: tracks tabs per window and
// pushes updates to the content script, and executes activate/close
// requests coming from the strip's UI. Fully standalone — no external
// mod (Windhawk or otherwise) required.

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'STS_GET_TABS') {
    const windowId = sender.tab?.windowId;
    if (windowId == null) { sendResponse({ tabs: [] }); return; }
    getTabsForWindow(windowId).then(tabs => sendResponse({ tabs }));
    return true; // async response
  }

  if (msg.type === 'STS_ACTIVATE_TAB') {
    chrome.tabs.update(msg.tabId, { active: true }).catch(() => {});
    return;
  }

  if (msg.type === 'STS_CLOSE_TAB') {
    chrome.tabs.remove(msg.tabId).catch(() => {});
    return;
  }
});

async function getTabsForWindow(windowId) {
  const tabs = await chrome.tabs.query({ windowId });
  return tabs
    .sort((a, b) => a.index - b.index)
    .map(t => ({
      id: t.id,
      title: t.title || '',
      favIconUrl: t.favIconUrl || '',
      active: t.active,
      pinned: t.pinned
    }));
}

// Debounce broadcasts per window so a burst of events (e.g. page loading,
// favicon arriving, title changing) collapses into one update.
const pending = new Map();

function scheduleBroadcast(windowId) {
  if (windowId == null || windowId === chrome.windows.WINDOW_ID_NONE) return;
  if (pending.has(windowId)) return;
  const timer = setTimeout(async () => {
    pending.delete(windowId);
    const tabs = await getTabsForWindow(windowId);
    for (const t of tabs) {
      chrome.tabs.sendMessage(t.id, { type: 'STS_TABS_UPDATE', tabs }).catch(() => {});
    }
  }, 120);
  pending.set(windowId, timer);
}

chrome.tabs.onCreated.addListener(tab => scheduleBroadcast(tab.windowId));
chrome.tabs.onRemoved.addListener((_tabId, info) => scheduleBroadcast(info.windowId));
chrome.tabs.onActivated.addListener(info => scheduleBroadcast(info.windowId));
chrome.tabs.onMoved.addListener((_tabId, info) => scheduleBroadcast(info.windowId));
chrome.tabs.onAttached.addListener((_tabId, info) => scheduleBroadcast(info.newWindowId));
chrome.tabs.onDetached.addListener((_tabId, info) => scheduleBroadcast(info.oldWindowId));
chrome.tabs.onUpdated.addListener((_tabId, changeInfo, tab) => {
  if (changeInfo.title !== undefined || changeInfo.favIconUrl !== undefined || changeInfo.status === 'complete') {
    scheduleBroadcast(tab.windowId);
  }
});
