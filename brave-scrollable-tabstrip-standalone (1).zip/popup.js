'use strict';
// MV3's default Content Security Policy blocks inline <script> tags in
// extension pages, so this logic must live in its own file (referenced via
// <script src="popup.js">) rather than inline in popup.html.

chrome.tabs.query({ currentWindow: true }, tabs => {
  const el = document.getElementById('tab-count');
  if (el) el.textContent = tabs ? tabs.length : '?';
});
